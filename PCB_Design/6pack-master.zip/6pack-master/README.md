# 6pack
KiCad files for 6pack macroPad

# Guide
1. Solder diodes
2. Solder reset button
3. clip reset button pins (interferes with switches)
4. Solder the pro micro header pins (do not solder the pro micro itself)
5. Solder the switches / rotary encoder
6. Clip switches under the pro micro (so it doesn't make contact)
7. Solder Pro Micro on with the components facing the PCB.
8. Add hotglue to the Pro Micro or make it hotswappable
